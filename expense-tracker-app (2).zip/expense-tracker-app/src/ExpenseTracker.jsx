const ExpenseTracker = () =>{
    return(
        <div>Expense Tracker</div>
    )
}
export default ExpenseTracker;