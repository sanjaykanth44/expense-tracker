import React, { useEffect } from "react";
import TransactionForm from "./components/TransactionForm";
import TransactionList from "./components/TransactionList";
import { useState } from "react";
import axios from "axios";

const transactions = [ // Fixed typo in the variable name
  
];

// inorder to get the data from the transactionform 
// a function is created in parert (App)
// and passed to the transactionform


const App = () => {
  const [transactions,setTransactions] = useState([{
    id: 1,
    title: 'Snacks',
    amount: -20
  },
  {
    id: 2,
    title: 'Salary',
    amount: 300 
  },
  {
    id: 3,
    title: 'Book',
    amount: -10 
  },
  {
    id: 4,
    title: 'Camera',
    amount: -150
  }])

  useEffect(() => {
    const fetchData = async () => {
        const response = await axios.get("http://localhost:3000/api/expenses");
        setTransactions(response.data);
      
    };
    
    fetchData();
  }, []);

  const addTransaction = (title,amount) => {
    console.log("Add =>" ,title,amount);
    const newTxn = {
      id: transactions.length+1,
      title: title,
      amount: amount
    }
    setTransactions([...transactions,newTxn])
  }
  
  return (
    <>
       
      <h1>Expense Tracker</h1>
      <TransactionList transactions={transactions} /> 
      <TransactionForm addTransaction={addTransaction}/>
    </>
  );
};

export default App;
