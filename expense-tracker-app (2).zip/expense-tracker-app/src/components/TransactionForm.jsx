import { useState } from "react";
const TransactionForm = (props) =>{
    const [title, setTitle] = useState("");
    const [amount, setAmount] = useState(0);

    const handleSubmit= (e) =>{
        e.preventDefault();
        props.addTransaction(title,amount)
    }
    const handleTitleChange = (e) =>{
        setTitle(e.target.value);
        // console.log("changed title: ",title)0
        
    }
    const handleAmountChange = (e) => {
        setAmount(e.target.value);
        // console.log("changed amount: ",amount)
    }

    return(
        <>
            <h1>New Transaction</h1>
            <h1>Title</h1>
            <h1>Amount</h1>
            <hr />
            <form> 
                <div>
                    <label htmlFor="title">Title</label>
                    <input type = "text" id = "title" onChange={handleTitleChange}/>
                </div>
                <div>
                    <label htmlFor="amount">Amount</label>
                    <input type="text" id = "amount" onChange={handleAmountChange}/>
                </div>
                <button onClick={handleSubmit}>Submit</button>
            </form>
             
        </>
    )
}
export default TransactionForm;